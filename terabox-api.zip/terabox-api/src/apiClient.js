const axios = require('axios');
const { generateRequestId, formatFileSize, buildCookieString, cache } = require('./utils');

class TeraboxApiClient {
  constructor(cookieNdus, bdstoken, appId = '250528') {
    this.cookieNdus = cookieNdus;
    this.bdstoken = bdstoken;
    this.appId = appId;
    this.baseUrl = 'https://www.terabox.com';
    
    this.httpClient = axios.create({
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.9',
        'X-Requested-With': 'XMLHttpRequest',
        'Cookie': buildCookieString(cookieNdus),
        'Referer': 'https://www.terabox.com/'
      },
      timeout: 20000
    });
  }

  async getFileList(shareUrl, jsToken, pwd = null) {
    const surl = shareUrl.match(/s\/([a-zA-Z0-9_-]+)/) || shareUrl.match(/surl=([a-zA-Z0-9_-]+)/);
    if (!surl) throw new Error('Invalid share URL');
    
    const shortId = surl[1];
    const cacheKey = `filelist:${shortId}:${pwd || 'nopwd'}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;

    try {
      const timestamp = Date.now();
      const params = {
        app_id: this.appId,
        web: '1',
        channel: 'dubox',
        clienttype: '0',
        bdstoken: this.bdstoken,
        surl: shortId,
        page: '1',
        num: '20',
        by: 'name',
        order: 'asc',
        t: timestamp,
        jsToken: jsToken
      };
      if (pwd) params.pwd = pwd;

      const response = await this.httpClient.get(`${this.baseUrl}/share/list`, { params });

      if (response.data.errno !== 0) {
        throw new Error(`Terabox API Error ${response.data.errno}: ${response.data.errmsg || 'Unknown error'}`);
      }

      const fileList = response.data.list.map(file => ({
        fsId: file.fs_id,
        name: file.server_filename || file.filename,
        path: file.path,
        size: formatFileSize(file.size),
        sizeBytes: file.size,
        isDir: file.isdir === '1',
        category: file.category,
        md5: file.md5,
        createTime: file.local_ctime ? new Date(parseInt(file.local_ctime) * 1000).toISOString() : null,
        modifyTime: file.local_mtime ? new Date(parseInt(file.local_mtime) * 1000).toISOString() : null,
        thumbnail: file.thumbs || null,
        icon: file.icon || null
      }));

      const result = {
        errno: response.data.errno,
        requestId: response.data.request_id || generateRequestId(),
        serverTime: response.data.server_time,
        title: response.data.title || fileList[0]?.name || 'Untitled',
        totalCount: response.data.count || fileList.length,
        files: fileList,
        uk: response.data.uk
      };

      cache.set(cacheKey, result, 300);
      return result;

    } catch (error) {
      if (error.response?.status === 412) {
        throw new Error('Password required or invalid token. Use pwd parameter.');
      }
      throw new Error(`API request failed: ${error.message}`);
    }
  }

  async getDirectDownloadLink(file, jsToken) {
    const cacheKey = `dlink:${file.fsId}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;

    try {
      const timestamp = Date.now();
      const params = {
        app_id: this.appId,
        web: '1',
        channel: 'dubox',
        clienttype: '0',
        bdstoken: this.bdstoken,
        fs_id: file.fsId,
        uk: file.uk || '',
        t: timestamp,
        jsToken: jsToken
      };

      const response = await this.httpClient.get(`${this.baseUrl}/share/download`, { params });

      if (response.data.errno !== 0) {
        throw new Error(`Download API error ${response.data.errno}`);
      }

      const dlData = response.data;
      const downloadLink = dlData.dlink || dlData.download_link || dlData.url || null;
      
      const result = {
        directUrl: downloadLink ? this._makeAbsoluteUrl(downloadLink) : null,
        fileName: dlData.file_name || file.name,
        size: formatFileSize(dlData.size || file.sizeBytes),
        sizeBytes: dlData.size || file.sizeBytes,
        md5: dlData.md5 || file.md5
      };

      cache.set(cacheKey, result, 600);
      return result;

    } catch (error) {
      throw new Error(`Failed to get download link: ${error.message}`);
    }
  }

  async getStreamUrls(fsId, jsToken, uk) {
    try {
      const timestamp = Date.now();
      const params = {
        app_id: this.appId,
        web: '1',
        channel: 'dubox',
        clienttype: '0',
        bdstoken: this.bdstoken,
        fs_id: fsId,
        uk: uk,
        type: 'M3U8_AUTO_360',
        t: timestamp,
        jsToken: jsToken
      };

      const response = await this.httpClient.get(`${this.baseUrl}/share/stream`, { params });

      if (response.data.errno !== 0) {
        throw new Error(`Stream API error ${response.data.errno}`);
      }

      return {
        m3u8Url: response.data.m3u8_url || null,
        resolutions: response.data.resolutions || [],
        duration: response.data.duration || null
      };

    } catch (error) {
      throw new Error(`Failed to get stream URLs: ${error.message}`);
    }
  }

  _makeAbsoluteUrl(url) {
    if (!url) return null;
    if (url.startsWith('http')) return url;
    return `${this.baseUrl}${url}`;
  }
}

module.exports = TeraboxApiClient;
