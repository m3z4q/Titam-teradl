const axios = require('axios');
const cheerio = require('cheerio');
const { extractShortUrl, cache } = require('./utils');

class TeraboxScraper {
  constructor(cookieNdus) {
    this.cookieNdus = cookieNdus;
    this.baseUrl = 'https://www.terabox.com';
  }

  async scrapeSharePage(shareUrl) {
    const surl = extractShortUrl(shareUrl);
    if (!surl) throw new Error('Invalid Terabox URL format');

    const cacheKey = `sharepage:${surl}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;

    try {
      const embedUrl = `${this.baseUrl}/sharing/link?surl=${surl}`;
      
      const response = await axios.get(embedUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cookie': `ndus=${this.cookieNdus}`,
          'Referer': 'https://www.terabox.com/'
        },
        timeout: 15000
      });

      const $ = cheerio.load(response.data);
      
      let jsToken = null;
      const scripts = $('script').map((i, el) => $(el).html()).get();
      
      for (const script of scripts) {
        const tokenMatch = script.match(/jsToken\s*[=:]\s*["']([^"']+)["']/);
        if (tokenMatch) { jsToken = tokenMatch[1]; break; }
        const tokenMatch2 = script.match(/"jsToken"\s*:\s*"([^"]+)"/);
        if (tokenMatch2) { jsToken = tokenMatch2[1]; break; }
      }

      const metadata = {
        title: $('title').text().trim() || null,
        filename: null,
        thumbnail: null
      };

      for (const script of scripts) {
        if (script.includes('file_name') || script.includes('filename')) {
          const fnMatch = script.match(/file_name["']?\s*[:=]\s*["']([^"']+)["']/);
          if (fnMatch) metadata.filename = fnMatch[1];
          const thumbMatch = script.match(/thumb["']?\s*[:=]\s*["']([^"']+)["']/);
          if (thumbMatch) metadata.thumbnail = thumbMatch[1];
          const sizeMatch = script.match(/size["']?\s*[:=]\s*(\d+)/);
          if (sizeMatch) metadata.size = parseInt(sizeMatch[1]);
        }
      }

      const result = { surl, jsToken, pageMetadata: metadata };
      cache.set(cacheKey, result);
      return result;

    } catch (error) {
      throw new Error(`Failed to scrape share page: ${error.message}`);
    }
  }

  async getJsToken(shareUrl) {
    const scraped = await this.scrapeSharePage(shareUrl);
    return scraped.jsToken;
  }
}

module.exports = TeraboxScraper;
