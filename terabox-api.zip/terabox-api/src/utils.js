const crypto = require('crypto');
const NodeCache = require('node-cache');

const cache = new NodeCache({ stdTTL: 600, checkperiod: 120 });

function generateRequestId() {
  return Date.now() + Math.floor(Math.random() * 100000);
}

function formatFileSize(bytes) {
  if (!bytes) return '0 B';
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
}

function extractShortUrl(teraboxUrl) {
  const patterns = [
    /s\/([a-zA-Z0-9_-]+)/,
    /sharing\/link\?surl=([a-zA-Z0-9_-]+)/
  ];
  for (const pattern of patterns) {
    const match = teraboxUrl.match(pattern);
    if (match) return match[1];
  }
  return null;
}

function buildCookieString(ndus) {
  return `ndus=${ndus}; lang=en_US; PANWEB=1; browserid=${crypto.randomBytes(24).toString('base64')}`;
}

module.exports = {
  cache,
  generateRequestId,
  formatFileSize,
  extractShortUrl,
  buildCookieString
};
