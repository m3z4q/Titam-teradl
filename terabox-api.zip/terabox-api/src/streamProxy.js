const axios = require('axios');
const { cache } = require('./utils');

class StreamProxy {
  constructor() {
    this.httpClient = axios.create({
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
  }

  async fetchM3U8(m3u8Url, jsToken) {
    const cacheKey = `m3u8:${m3u8Url}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;

    try {
      const response = await this.httpClient.get(m3u8Url, {
        headers: {
          'Referer': 'https://www.terabox.com/',
          'Cookie': `jsToken=${jsToken}`
        }
      });

      const baseUrl = m3u8Url.substring(0, m3u8Url.lastIndexOf('/') + 1);
      const rewritten = this._rewriteM3U8(response.data, baseUrl);

      cache.set(cacheKey, rewritten, 120);
      return rewritten;

    } catch (error) {
      throw new Error(`Failed to fetch M3U8: ${error.message}`);
    }
  }

  _rewriteM3U8(content, baseUrl) {
    const lines = content.split('\n');
    const rewritten = [];

    for (const line of lines) {
      if (line.trim() && !line.startsWith('#') && line.startsWith('http')) {
        rewritten.push(`/api/proxy/segment?url=${encodeURIComponent(line)}`);
      } else if (line.trim() && !line.startsWith('#') && !line.startsWith('http')) {
        rewritten.push(`/api/proxy/segment?url=${encodeURIComponent(baseUrl + line)}`);
      } else {
        rewritten.push(line);
      }
    }

    return rewritten.join('\n');
  }

  async proxySegment(segmentUrl) {
    try {
      const response = await this.httpClient.get(segmentUrl, {
        responseType: 'stream',
        headers: { 'Referer': 'https://www.terabox.com/' }
      });
      return response;
    } catch (error) {
      throw new Error(`Failed to proxy segment: ${error.message}`);
    }
  }
}

module.exports = StreamProxy;
