# 🚀 Terabox Video API

> Created by **TITANGOD** | Telegram: **[@g0zig](https://t.me/g0zig)**

## Features
- Terabox share links se video info aur download links fetch karein
- HLS Streaming support (M3U8)
- Multiple file support
- Direct download links
- Password-protected link support

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | API Info |
| GET | `/api/health` | Health Check |
| GET | `/api/video?url=LINK` | Get video + download links |
| POST | `/api/video` | Same as GET (JSON body) |
| GET | `/api/metadata?url=LINK` | Just metadata (fast) |
| GET | `/api/stream/m3u8?url=M3U8_URL` | HLS Playlist proxy |
| GET | `/api/proxy/segment?url=SEG_URL` | Video segment proxy |

## Usage

```bash
# Get video info
curl "https://your-domain.up.railway.app/api/video?url=https://terabox.com/s/SHARE_LINK"

# With password
curl "https://your-domain.up.railway.app/api/video?url=LINK&pwd=PASSWORD"

# Health check
curl "https://your-domain.up.railway.app/api/health"
