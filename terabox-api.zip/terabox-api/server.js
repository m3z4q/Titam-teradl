require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const TeraboxScraper = require('./src/scraper');
const TeraboxApiClient = require('./src/apiClient');
const StreamProxy = require('./src/streamProxy');
const { extractShortUrl } = require('./src/utils');

const app = express();
const PORT = process.env.PORT || 3000;

// ====================================================
// 🏆 TERABOX VIDEO API
// Created by: TITANGOD
// Telegram: @g0zig
// ====================================================

const CREATOR = {
  name: "TITANGOD",
  telegram: "@g0zig",
  version: "1.0.0"
};

// Initialize components
const scraper = new TeraboxScraper(process.env.COOKIE_NDUS);
const apiClient = new TeraboxApiClient(
  process.env.COOKIE_NDUS,
  process.env.BDSTOKEN,
  process.env.APP_ID
);
const streamProxy = new StreamProxy();

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// ==================== API ROUTES ====================

/**
 * GET /
 * Root endpoint - Shows API info with creator credit
 */
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: "Terabox Video API",
    creator: CREATOR,
    endpoints: {
      health: "/api/health",
      video: "/api/video?url=TERABOX_LINK",
      metadata: "/api/metadata?url=TERABOX_LINK",
      stream_m3u8: "/api/stream/m3u8?url=M3U8_URL",
      stream_segment: "/api/proxy/segment?url=SEGMENT_URL"
    },
    powered_by: "TITANGOD"
  });
});

/**
 * GET /api/health
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: CREATOR.version,
    creator: CREATOR.name,
    telegram: CREATOR.telegram,
    message: 'Terabox Video API is running 🔥'
  });
});

/**
 * GET /api/video?url=TERABOX_SHARE_LINK
 */
app.get('/api/video', async (req, res) => {
  try {
    const { url } = req.query;
    const pwd = req.query.pwd || null;

    if (!url) {
      return res.status(400).json({
        success: false,
        creator: CREATOR,
        error: 'Missing required parameter: url'
      });
    }

    const surl = extractShortUrl(url);
    if (!surl) {
      return res.status(400).json({
        success: false,
        creator: CREATOR,
        error: 'Invalid Terabox URL format'
      });
    }

    const pageData = await scraper.scrapeSharePage(url);
    
    if (!pageData.jsToken) {
      return res.status(400).json({
        success: false,
        creator: CREATOR,
        error: 'Could not extract jsToken. The link may be invalid or require login.'
      });
    }

    const fileList = await apiClient.getFileList(url, pageData.jsToken, pwd);

    const videoFiles = fileList.files.filter(f => 
      !f.isDir && ['1', '3'].includes(f.category)
    );

    const processedVideos = [];
    
    for (const file of videoFiles) {
      try {
        const downloadInfo = await apiClient.getDirectDownloadLink(
          { fsId: file.fsId, uk: fileList.uk, ...file }, 
          pageData.jsToken
        );
        
        let streamInfo = null;
        try {
          streamInfo = await apiClient.getStreamUrls(file.fsId, pageData.jsToken, fileList.uk);
        } catch (e) {}

        processedVideos.push({
          id: file.fsId,
          name: file.name,
          size: file.size,
          sizeBytes: file.sizeBytes,
          thumbnail: file.thumbnail,
          download: {
            url: downloadInfo.directUrl,
            fileName: downloadInfo.fileName
          },
          stream: streamInfo ? {
            m3u8: streamInfo.m3u8Url,
            resolutions: streamInfo.resolutions,
            duration: streamInfo.duration
          } : null,
          metadata: {
            md5: file.md5,
            created: file.createTime,
            modified: file.modifyTime
          }
        });
      } catch (err) {
        processedVideos.push({
          id: file.fsId,
          name: file.name,
          error: err.message
        });
      }
    }

    let singleFile = null;
    if (processedVideos.length === 1 && fileList.files.length === 1) {
      singleFile = processedVideos[0];
    }

    res.json({
      success: true,
      creator: CREATOR,
      requestId: fileList.requestId,
      title: fileList.title,
      ...(singleFile ? {
        name: singleFile.name,
        size: singleFile.size,
        sizeBytes: singleFile.sizeBytes,
        thumbnail: singleFile.thumbnail,
        downloadUrl: singleFile.download?.url,
        streamUrl: singleFile.stream?.m3u8
      } : {}),
      files: processedVideos,
      raw: {
        errno: fileList.errno,
        totalCount: fileList.totalCount,
        uk: fileList.uk
      }
    });

  } catch (error) {
    console.error('Error processing video:', error.message);
    res.status(500).json({
      success: false,
      creator: CREATOR,
      error: error.message
    });
  }
});

/**
 * GET /api/metadata?url=TERABOX_SHARE_LINK
 */
app.get('/api/metadata', async (req, res) => {
  try {
    const { url } = req.query;
    
    if (!url) {
      return res.status(400).json({ success: false, creator: CREATOR, error: 'Missing url parameter' });
    }

    const pageData = await scraper.scrapeSharePage(url);
    const fileList = await apiClient.getFileList(url, pageData.jsToken);

    res.json({
      success: true,
      creator: CREATOR,
      surl: pageData.surl,
      title: fileList.title,
      totalFiles: fileList.totalCount,
      files: fileList.files.map(f => ({
        name: f.name,
        size: f.size,
        isDirectory: f.isDir,
        thumbnail: f.thumbnail
      })),
      hasToken: !!pageData.jsToken
    });

  } catch (error) {
    res.status(500).json({ success: false, creator: CREATOR, error: error.message });
  }
});

/**
 * GET /api/stream/m3u8?url=M3U8_URL
 */
app.get('/api/stream/m3u8', async (req, res) => {
  try {
    const { url } = req.query;
    const jsToken = req.query.jsToken || '';

    if (!url) {
      return res.status(400).json({ success: false, creator: CREATOR, error: 'Missing url parameter' });
    }

    const m3u8Content = await streamProxy.fetchM3U8(url, jsToken);
    
    res.set({
      'Content-Type': 'application/vnd.apple.mpegurl',
      'Access-Control-Allow-Origin': '*'
    });
    res.send(m3u8Content);

  } catch (error) {
    res.status(500).json({ success: false, creator: CREATOR, error: error.message });
  }
});

/**
 * GET /api/proxy/segment?url=SEGMENT_URL
 */
app.get('/api/proxy/segment', async (req, res) => {
  try {
    const { url } = req.query;
    
    if (!url) {
      return res.status(400).json({ success: false, creator: CREATOR, error: 'Missing url parameter' });
    }

    const response = await streamProxy.proxySegment(url);
    
    res.set({
      'Content-Type': response.headers['content-type'] || 'video/mp2t',
      'Content-Length': response.headers['content-length'],
      'Access-Control-Allow-Origin': '*'
    });
    
    response.data.pipe(res);

  } catch (error) {
    res.status(500).json({ success: false, creator: CREATOR, error: error.message });
  }
});

/**
 * POST /api/video
 */
app.post('/api/video', async (req, res) => {
  const { url, pwd } = req.body;
  
  if (!url) {
    return res.status(400).json({
      success: false,
      creator: CREATOR,
      error: 'Missing url in request body'
    });
  }

  req.query = { url, pwd };
  app._router.handle(req, res, () => {});
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    creator: CREATOR,
    error: 'Endpoint not found',
    available: ['/', '/api/health', '/api/video', '/api/metadata', '/api/stream/m3u8', '/api/proxy/segment']
  });
});

// Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    success: false,
    creator: CREATOR,
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// ==================== START SERVER ====================
app.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════════╗
  ║     🚀 TERABOX VIDEO API 🚀          ║
  ║                                       ║
  ║     Created by: TITANGOD              ║
  ║     Telegram: @g0zig                  ║
  ║                                       ║
  ║     Running on port ${PORT}             ║
  ╚═══════════════════════════════════════╝
  `);
});
